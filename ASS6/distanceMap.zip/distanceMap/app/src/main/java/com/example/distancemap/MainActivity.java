package com.example.distancemap;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.SphericalUtil;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap gmap;
    private EditText locationOne, locationTwo;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI elements
        locationOne = findViewById(R.id.location_one);
        locationTwo = findViewById(R.id.location_two);
        calculateButton = findViewById(R.id.calculate_button);

        // Initialize Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapfragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Button Click Listener
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String placeOne = locationOne.getText().toString();
                String placeTwo = locationTwo.getText().toString();

                if (!placeOne.isEmpty() && !placeTwo.isEmpty()) {
                    calculateDistance(placeOne, placeTwo);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter both locations", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gmap = googleMap;
    }

    private void calculateDistance(String placeOne, String placeTwo) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            // Get Coordinates for First Location
            List<Address> addressList1 = geocoder.getFromLocationName(placeOne, 1);
            List<Address> addressList2 = geocoder.getFromLocationName(placeTwo, 1);

            if (addressList1 != null && !addressList1.isEmpty() && addressList2 != null && !addressList2.isEmpty()) {
                LatLng latLngOne = new LatLng(addressList1.get(0).getLatitude(), addressList1.get(0).getLongitude());
                LatLng latLngTwo = new LatLng(addressList2.get(0).getLatitude(), addressList2.get(0).getLongitude());

                // Clear previous markers
                gmap.clear();

                // Add markers to both locations
                gmap.addMarker(new MarkerOptions().position(latLngOne).title("Location 1: " + placeOne));
                gmap.addMarker(new MarkerOptions().position(latLngTwo).title("Location 2: " + placeTwo));

                // Move camera to show both locations
                gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLngOne, 5));

                // Calculate distance
                double distance = SphericalUtil.computeDistanceBetween(latLngOne, latLngTwo);
                Toast.makeText(this, "Distance: " + (distance / 1000) + " km", Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(this, "One or both locations not found", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error finding locations", Toast.LENGTH_SHORT).show();
        }
    }
}
