package com.example.mapsearch;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    Button zoomin, zoomout , search;
    ToggleButton t1 ;

    EditText ed1;
    private GoogleMap gmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.mapStyle);
        zoomin = findViewById(R.id.zoomin);
        zoomout = findViewById(R.id.zoomout);
        search = findViewById(R.id.search);
        ed1 = findViewById(R.id.search_bar);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapfragment);
        mapFragment.getMapAsync(this);

        LatLng newlat;


    }
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gmap = googleMap;

        t1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    gmap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                }
                else{
                    gmap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                }
            }
        });

        zoomin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gmap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });

        zoomout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gmap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String loc = ed1.getText().toString();

                searchlocation(loc);
            }
        });

        gmap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {

                String name = getTouchLocation(latLng);

                gmap.clear();

                gmap.addMarker(new MarkerOptions().position(latLng).title(name));
                gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,12));

            }
        });
    }

    public void searchlocation(String loc){

        List<Address> addressList;
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            addressList = geocoder.getFromLocationName(loc, 1);

        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }

        Address addr = addressList.get(0);

        LatLng latlang = new LatLng(addr.getLatitude(),addr.getLongitude());
        gmap.addMarker(new MarkerOptions().title(loc).position(latlang));
        gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latlang,12));
    }

    public String getTouchLocation(LatLng latLng){

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try{

            List <Address> addrList = geocoder.getFromLocation(latLng.latitude,latLng.longitude,1);
            Address address =  addrList.get(0);
            return address.getAddressLine(0);

        }
        catch (Exception e){

        }
        return null;
    }

}