package com.example.ass4b2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtString, edtOutput;
    RadioGroup radioGroup;
    Button btnProcess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtString = findViewById(R.id.edtString);
        edtOutput = findViewById(R.id.edtOutput);
        radioGroup = findViewById(R.id.radioGroup);
        btnProcess = findViewById(R.id.btnProcess);

        btnProcess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processString();
            }
        });
    }

    private void processString() {
        String input = edtString.getText().toString();
        if (input.isEmpty()) {
            edtOutput.setText("Please enter a string");
            return;
        }

        int selectedId = radioGroup.getCheckedRadioButtonId();

        if (selectedId == R.id.rbUppercase) {
            edtOutput.setText(input.toUpperCase());
        } else if (selectedId == R.id.rbLowercase) {
            edtOutput.setText(input.toLowerCase());
        } else if (selectedId == R.id.rbRight5) {
            edtOutput.setText(getRightCharacters(input, 5));
        } else if (selectedId == R.id.rbLeft5) {
            edtOutput.setText(getLeftCharacters(input, 5));
        } else {
            edtOutput.setText("Please select an operation");
        }
    }

    private String getRightCharacters(String str, int length) {
        if (str.length() <= length) return str;
        return str.substring(str.length() - length);
    }

    private String getLeftCharacters(String str, int length) {
        if (str.length() <= length) return str;
        return str.substring(0, length);
    }
}
