package com.example.assignment4a2;

import android.media.TimedText;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView t1;
    Button b1;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        e1 = findViewById(R.id.num);
        b1 = findViewById(R.id.submit);
        t1 = findViewById(R.id.result);

        registerForContextMenu(b1);

    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if(itemId == R.id.factorial){

            String num = e1.getText().toString();
            t1.setText(factorial(num));
        } else if (itemId == R.id.sumofdigit) {

            String num = e1.getText().toString();
            t1.setText(sod(num));
        }
        return super.onContextItemSelected(item);
    }

    public String factorial(String num){

         int n = Integer.parseInt(num);

         int result = 1;
         if(n < 1){
             return "Enter Number Greater than 0";
         } else if (n==1) {
             return "1";

         }
        for(int i = n; i>=1 ;i--){
            result *=i;
         }

         String strnum = Integer.toString(result);

        return strnum;
    }


    public String sod(String num){

        String strnum = "";

        int sum = 0;
        for(int i = 0 ; i<num.length();i++){

            sum += Integer.parseInt(String.valueOf(num.charAt(i)));

        }
        strnum = Integer.toString(sum);

        return strnum;
    }
}