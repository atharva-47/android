package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtNumber, edtAnswer;
    RadioGroup radioGroup;
    Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNumber = findViewById(R.id.edtNumber);
        edtAnswer = findViewById(R.id.edtAnswer);
        radioGroup = findViewById(R.id.radioGroup);
        btnCalculate = findViewById(R.id.btnCalculate);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });
    }

    private void calculateResult() {
        String input = edtNumber.getText().toString();
        if (input.isEmpty()) {
            edtAnswer.setText("Please enter a number");
            return;
        }

        int num = Integer.parseInt(input);
        int selectedId = radioGroup.getCheckedRadioButtonId();

        if (selectedId == R.id.rbOddEven) {
            String result = (num % 2 == 0) ? "No is Even" : "No is Odd";
            edtAnswer.setText(result);
        } else if (selectedId == R.id.rbPositiveNegative) {
            String result = (num >= 0) ? "No is Positive" : "No is Negative";
            edtAnswer.setText(result);
        } else if (selectedId == R.id.rbSquare) {
            int square = num * num;
            edtAnswer.setText("Square: " + square);
        } else if (selectedId == R.id.rbFactorial) {
            edtAnswer.setText("Factorial: " + factorial(num));
        } else {
            edtAnswer.setText("Please select an operation");
        }
    }

    private long factorial(int n) {
        if (n < 0) return -1; // Factorial not defined for negative numbers
        long fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }
}
