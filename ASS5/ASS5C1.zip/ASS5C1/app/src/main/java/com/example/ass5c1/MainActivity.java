package com.example.ass5c1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    StudentDBHelper dbHelper;
    EditText inputName, updateId, updateName, deleteId;
    TextView studentList;
    Button addBtn, updateBtn, deleteBtn, showAllBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new StudentDBHelper(this);

        inputName = findViewById(R.id.inputName);
        updateId = findViewById(R.id.updateId);
        updateName = findViewById(R.id.updateName);
        deleteId = findViewById(R.id.deleteId);
        studentList = findViewById(R.id.studentList);

        addBtn = findViewById(R.id.addBtn);
        updateBtn = findViewById(R.id.updateBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        showAllBtn = findViewById(R.id.showAllBtn);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.insertStudent(inputName.getText().toString());
                inputName.setText("");
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.updateStudent(Integer.parseInt(updateId.getText().toString()), updateName.getText().toString());
                updateId.setText("");
                updateName.setText("");
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.deleteStudent(Integer.parseInt(deleteId.getText().toString()));
                deleteId.setText("");
            }
        });

        showAllBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = dbHelper.getAllStudents();
                StringBuilder data = new StringBuilder();
                while (cursor.moveToNext()) {
                    data.append("ID: ").append(cursor.getInt(0)).append(" | Name: ").append(cursor.getString(1)).append("\n");
                }
                cursor.close();
                studentList.setText(data.toString());
            }
        });
    }
}
