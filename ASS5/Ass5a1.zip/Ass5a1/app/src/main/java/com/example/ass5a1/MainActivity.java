package com.example.ass5a1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etName, etAddress, etPhone;
    Button btnInsert, btnShow;
    TextView tvCustomers;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etPhone = findViewById(R.id.etPhone);
        btnInsert = findViewById(R.id.btnInsert);
        btnShow = findViewById(R.id.btnShow);
        tvCustomers = findViewById(R.id.tvCustomers);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString();
                String address = etAddress.getText().toString();
                String phone = etPhone.getText().toString();

                if (name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill The Empty Fields", Toast.LENGTH_SHORT).show();


                } else {

                    boolean inserted = dbHelper.insertCustomer(name, address, phone);
                    if (inserted) {

                        Toast.makeText(MainActivity.this, "Customer Added", Toast.LENGTH_SHORT).show();
                        etName.setText("");
                        etAddress.setText("");
                        etPhone.setText("");

                    } else {

                        Toast.makeText(MainActivity.this, "Error Adding Customer", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomers();
            }
        });
    }

    private void showCustomers() {
        Cursor cursor = dbHelper.getAllCustomers();
        StringBuilder sb = new StringBuilder();
        if (cursor.getCount() == 0) {
            sb.append("No Customers Found.");
        } else {
            while (cursor.moveToNext()) {
                sb.append("ID: ").append(cursor.getInt(0)).append("\n");
                sb.append("Name: ").append(cursor.getString(1)).append("\n");
                sb.append("Address: ").append(cursor.getString(2)).append("\n");
                sb.append("Phone: ").append(cursor.getString(3)).append("\n\n");
            }
        }
        tvCustomers.setText(sb.toString());
    }
}
