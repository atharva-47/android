package com.example.ass5a2;


import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText dName, dPlace, eName, eAddr, ePhone, eSalary, eDeptId, delDept;
    Button addDept, addEmp, showEmps, delEmp;
    TextView empList;
    MyDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new MyDBHelper(this);

        dName = findViewById(R.id.dName);
        dPlace = findViewById(R.id.dPlace);
        eName = findViewById(R.id.eName);
        eAddr = findViewById(R.id.eAddr);
        ePhone = findViewById(R.id.ePhone);
        eSalary = findViewById(R.id.eSalary);
        eDeptId = findViewById(R.id.eDeptId);
        delDept = findViewById(R.id.delDept);

        addDept = findViewById(R.id.addDept);
        addEmp = findViewById(R.id.addEmp);
        showEmps = findViewById(R.id.showEmps);
        delEmp = findViewById(R.id.delEmp);
        empList = findViewById(R.id.empList);

        addDept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = dName.getText().toString();
                String place = dPlace.getText().toString();

                if (name.isEmpty() || place.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all fields!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (db.addDept(name, place)) {
                    Toast.makeText(MainActivity.this, "Dept Added", Toast.LENGTH_SHORT).show();
                    dName.setText("");
                    dPlace.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Error!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addEmp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = eName.getText().toString();
                String addr = eAddr.getText().toString();
                String phone = ePhone.getText().toString();
                String salaryText = eSalary.getText().toString();
                String deptIdText = eDeptId.getText().toString();

                if (name.isEmpty() || addr.isEmpty() || phone.isEmpty() || salaryText.isEmpty() || deptIdText.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all fields!", Toast.LENGTH_SHORT).show();
                    return;
                }

                int salary = Integer.parseInt(salaryText);
                int deptId = Integer.parseInt(deptIdText);

                if (db.addEmp(name, addr, phone, salary, deptId)) {
                    Toast.makeText(MainActivity.this, "Emp Added", Toast.LENGTH_SHORT).show();
                    eName.setText("");
                    eAddr.setText("");
                    ePhone.setText("");
                    eSalary.setText("");
                    eDeptId.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Error!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        showEmps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = db.getEmps();
                StringBuilder sb = new StringBuilder();

                if (cursor.getCount() == 0) {
                    sb.append("No Emps Found.");
                } else {
                    while (cursor.moveToNext()) {
                        sb.append("ID: ").append(cursor.getInt(0)).append("\n");
                        sb.append("Name: ").append(cursor.getString(1)).append("\n");
                        sb.append("Addr: ").append(cursor.getString(2)).append("\n");
                        sb.append("Phone: ").append(cursor.getString(3)).append("\n");
                        sb.append("Salary: ").append(cursor.getInt(4)).append("\n\n");
                    }
                }
                empList.setText(sb.toString());
            }
        });

        delEmp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String deptName = delDept.getText().toString();

                if (deptName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter dept name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                int deleted = db.deleteEmpsByDept(deptName);
                Toast.makeText(MainActivity.this, deleted + " Emps Deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
