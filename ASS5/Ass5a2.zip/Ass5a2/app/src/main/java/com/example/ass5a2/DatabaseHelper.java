package com.example.ass5a2;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class MyDBHelper extends SQLiteOpenHelper {

    public MyDBHelper(Context context) {
        super(context, "company.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE dept (dept_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, place TEXT)");
        db.execSQL("CREATE TABLE emp (emp_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, addr TEXT, phone TEXT, salary INTEGER, dept_id INTEGER, FOREIGN KEY(dept_id) REFERENCES dept(dept_id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS emp");
        db.execSQL("DROP TABLE IF EXISTS dept");
        onCreate(db);
    }

    public boolean addDept(String name, String place) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("place", place);
        return db.insert("dept", null, values) != -1;
    }

    public boolean addEmp(String name, String addr, String phone, int salary, int deptId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("addr", addr);
        values.put("phone", phone);
        values.put("salary", salary);
        values.put("dept_id", deptId);
        return db.insert("emp", null, values) != -1;
    }

    public Cursor getEmps() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM emp", null);
    }

    public int deleteEmpsByDept(String deptName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT dept_id FROM dept WHERE name=?", new String[]{deptName});

        if (cursor.moveToFirst()) {
            int deptId = cursor.getInt(0);
            return db.delete("emp", "dept_id=?", new String[]{String.valueOf(deptId)});
        }
        return 0;
    }
}
