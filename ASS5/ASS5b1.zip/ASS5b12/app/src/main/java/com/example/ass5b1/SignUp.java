package com.example.ass5b1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SignUp extends AppCompatActivity {

    MyDBHelper db;
    EditText ed1,ed2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);

        Button signup = findViewById(R.id.signupusr);
        db = new MyDBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                ed1 = findViewById(R.id.uname);
                ed2 = findViewById(R.id.passwd);


                boolean inserted  = db.insertInDB(ed1.getText().toString(),ed2.getText().toString());
                if(inserted){

                    Toast.makeText(SignUp.this, "Values Inserted ", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(SignUp.this, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}